const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

// Minimal built-in .env loader (avoids an extra dependency).
// Only sets variables that aren't already defined in the real environment.
(function loadDotEnv() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, "utf8").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    let value = trimmed.slice(idx + 1).trim();
    if (/^".*"$/.test(value) || /^'.*'$/.test(value)) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value;
  }
})();

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, "data.json");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const TOKEN_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

// Paymob (Egyptian payment gateway) configuration — set these in .env before going live
const PAYMOB_API_KEY = process.env.PAYMOB_API_KEY || "";
const PAYMOB_INTEGRATION_ID = process.env.PAYMOB_INTEGRATION_ID || "";
const PAYMOB_IFRAME_ID = process.env.PAYMOB_IFRAME_ID || "";
const PAYMOB_HMAC_SECRET = process.env.PAYMOB_HMAC_SECRET || "";
const PAYMOB_BASE = "https://accept.paymob.com/api";
const PAYMOB_CONFIGURED = PAYMOB_API_KEY && PAYMOB_INTEGRATION_ID && PAYMOB_IFRAME_ID && PAYMOB_HMAC_SECRET;
const PENDING_ORDER_TIMEOUT_MS = 30 * 60 * 1000; // abandon unpaid orders after 30 minutes

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[0-9+\s-]{8,20}$/;
const ORDER_STATUSES = ["بانتظار الدفع", "قيد التجهيز", "تم الشحن", "تم التسليم", "ملغى", "فشل الدفع"];
const PAID_STATUSES = ["قيد التجهيز", "تم الشحن", "تم التسليم"];

app.use(express.json());

// Handle malformed JSON bodies gracefully instead of crashing with a raw 500
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "صيغة البيانات غير صحيحة" });
  }
  next(err);
});

app.use(express.static(path.join(__dirname, "public")));

// ---------- Data layer ----------

function defaultDB() {
  return {
    products: [
      { id: 1, name: "طعام الحيوانات", price: 15, stock: 24, emoji: "🥩" },
      { id: 2, name: "ألعاب", price: 10, stock: 18, emoji: "🧸" },
      { id: 3, name: "أدوات العناية", price: 12, stock: 31, emoji: "🧴" }
    ],
    orders: [],
    messages: []
  };
}

function saveDB(db) {
  const temp = DB_FILE + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), "utf8");
  fs.renameSync(temp, DB_FILE);
}

function loadDB() {
  if (!fs.existsSync(DB_FILE)) {
    const db = defaultDB();
    saveDB(db);
    return db;
  }
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch {
    console.error("data.json تالف، سيتم إنشاء قاعدة بيانات جديدة");
    const db = defaultDB();
    saveDB(db);
    return db;
  }
}

let db = loadDB();
if (!Array.isArray(db.messages)) db.messages = []; // backward compatibility with older data.json

function restoreStock(order) {
  for (const item of order.items) {
    const product = db.products.find(p => p.id === item.id);
    if (product) product.stock += item.quantity;
  }
}

// Orders left unpaid for too long (customer abandoned checkout) are cancelled
// and their reserved stock is given back automatically.
function expireAbandonedOrders() {
  const cutoff = Date.now() - PENDING_ORDER_TIMEOUT_MS;
  let changed = false;
  for (const order of db.orders) {
    if (order.status === "بانتظار الدفع" && new Date(order.createdAt).getTime() < cutoff) {
      order.status = "فشل الدفع";
      restoreStock(order);
      changed = true;
    }
  }
  if (changed) saveDB(db);
}

setInterval(expireAbandonedOrders, 5 * 60 * 1000);

// ---------- Admin auth (simple token-based) ----------

const sessions = new Map(); // token -> expiry timestamp

function cleanupSessions() {
  const now = Date.now();
  for (const [token, expiry] of sessions) {
    if (expiry < now) sessions.delete(token);
  }
}

function requireAdmin(req, res, next) {
  cleanupSessions();
  const token = req.headers["x-admin-token"];
  if (!token || !sessions.has(token)) {
    return res.status(401).json({ error: "يجب تسجيل الدخول كمسؤول" });
  }
  next();
}

app.post("/api/admin/login", (req, res) => {
  const { password } = req.body || {};
  if (password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "كلمة المرور غير صحيحة" });
  }
  const token = crypto.randomBytes(24).toString("hex");
  sessions.set(token, Date.now() + TOKEN_TTL_MS);
  res.json({ token });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  sessions.delete(req.headers["x-admin-token"]);
  res.json({ ok: true });
});

// ---------- Paymob helpers ----------

async function paymobRequest(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = (data && (data.message || data.detail)) || `Paymob request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

async function paymobAuthenticate() {
  const data = await paymobRequest(`${PAYMOB_BASE}/auth/tokens`, { api_key: PAYMOB_API_KEY });
  return data.token;
}

async function paymobCreateOrder(authToken, amountCents, merchantOrderId, items) {
  const data = await paymobRequest(`${PAYMOB_BASE}/ecommerce/orders`, {
    auth_token: authToken,
    delivery_needed: false,
    amount_cents: amountCents,
    currency: "EGP",
    merchant_order_id: merchantOrderId,
    items: items.map(it => ({
      name: it.name.slice(0, 60),
      amount_cents: Math.round(it.price * 100),
      description: it.name.slice(0, 60),
      quantity: it.quantity
    }))
  });
  return data.id;
}

async function paymobGetPaymentKey(authToken, amountCents, paymobOrderId, billingData) {
  const data = await paymobRequest(`${PAYMOB_BASE}/acceptance/payment_keys`, {
    auth_token: authToken,
    amount_cents: amountCents,
    expiration: 3600,
    order_id: paymobOrderId,
    billing_data: billingData,
    currency: "EGP",
    integration_id: Number(PAYMOB_INTEGRATION_ID)
  });
  return data.token;
}

// Verifies the HMAC Paymob sends with "transaction processed" callbacks.
// Field order below is fixed by Paymob's spec — do not reorder.
function verifyPaymobHmac(obj, receivedHmac) {
  const fields = [
    "amount_cents", "created_at", "currency", "error_occured", "has_parent_transaction",
    "id", "integration_id", "is_3d_secure", "is_auth", "is_capture", "is_refunded",
    "is_standalone_payment", "is_voided", "order.id", "owner", "pending",
    "source_data.pan", "source_data.sub_type", "source_data.type", "success"
  ];
  const getVal = (key) => {
    const parts = key.split(".");
    let val = obj;
    for (const p of parts) val = val == null ? undefined : val[p];
    return val === undefined || val === null ? "" : String(val);
  };
  const concatenated = fields.map(getVal).join("");
  const computed = crypto.createHmac("sha512", PAYMOB_HMAC_SECRET).update(concatenated).digest("hex");
  if (computed.length !== receivedHmac.length) return false;
  return crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(receivedHmac));
}

// ---------- Public: products ----------

app.get("/api/products", (req, res) => {
  expireAbandonedOrders();
  res.json(db.products);
});

// ---------- Public: orders ----------

app.post("/api/orders", (req, res) => {
  const { customer, items } = req.body || {};

  if (!customer || !customer.name || !customer.email || !EMAIL_RE.test(customer.email))
    return res.status(400).json({ error: "بيانات العميل غير صحيحة" });

  if (!customer.phone || !PHONE_RE.test(customer.phone))
    return res.status(400).json({ error: "رقم الهاتف غير صحيح" });

  if (!Array.isArray(items) || !items.length)
    return res.status(400).json({ error: "السلة فارغة" });

  let total = 0;
  const orderItems = [];

  for (const item of items) {
    const product = db.products.find(p => p.id === Number(item.id));
    const quantity = Number(item.quantity);
    if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > product.stock)
      return res.status(400).json({ error: `الكمية غير متاحة للمنتج: ${product ? product.name : item.id}` });
    total += product.price * quantity;
    orderItems.push({ id: product.id, name: product.name, quantity, price: product.price });
  }

  for (const item of orderItems)
    db.products.find(p => p.id === item.id).stock -= item.quantity;

  const nextId = db.orders.length ? Math.max(...db.orders.map(o => o.id)) + 1 : 1001;
  const order = {
    id: nextId,
    customer: {
      name: String(customer.name).slice(0, 100),
      email: String(customer.email).slice(0, 100),
      phone: String(customer.phone).slice(0, 20)
    },
    items: orderItems,
    total,
    status: PAYMOB_CONFIGURED ? "بانتظار الدفع" : "قيد التجهيز",
    paymobOrderId: null,
    createdAt: new Date().toISOString()
  };

  db.orders.push(order);
  saveDB(db);
  res.status(201).json(order);
});

// Starts a Paymob payment session for an order and returns the hosted checkout URL.
app.post("/api/orders/:id/pay", async (req, res) => {
  const order = db.orders.find(o => o.id === Number(req.params.id));
  if (!order) return res.status(404).json({ error: "الطلب غير موجود" });
  if (order.status !== "بانتظار الدفع")
    return res.status(400).json({ error: "هذا الطلب لا ينتظر دفعًا" });
  if (!PAYMOB_CONFIGURED)
    return res.status(503).json({ error: "بوابة الدفع غير مُفعّلة بعد، تواصل مع صاحب المتجر" });

  try {
    const amountCents = Math.round(order.total * 100);
    const authToken = await paymobAuthenticate();
    const paymobOrderId = await paymobCreateOrder(authToken, amountCents, `petcare-${order.id}`, order.items);

    const [firstName, ...rest] = order.customer.name.trim().split(/\s+/);
    const billingData = {
      first_name: firstName || "NA",
      last_name: rest.join(" ") || "NA",
      email: order.customer.email,
      phone_number: order.customer.phone,
      apartment: "NA", floor: "NA", street: "NA", building: "NA",
      shipping_method: "NA", postal_code: "NA", city: "NA", country: "EG", state: "NA"
    };

    const paymentToken = await paymobGetPaymentKey(authToken, amountCents, paymobOrderId, billingData);

    order.paymobOrderId = paymobOrderId;
    saveDB(db);

    res.json({ iframeUrl: `${PAYMOB_BASE}/acceptance/iframes/${PAYMOB_IFRAME_ID}?payment_token=${paymentToken}` });
  } catch (err) {
    console.error("Paymob error:", err.message);
    res.status(502).json({ error: "تعذر بدء عملية الدفع، حاول مرة أخرى" });
  }
});

// Server-to-server webhook Paymob calls after a transaction is processed.
// Configure this URL as the "Transaction processed callback" in the Paymob dashboard.
app.post("/api/payments/webhook", (req, res) => {
  try {
    const receivedHmac = req.query.hmac;
    const data = (req.body && req.body.obj) || req.body;
    if (!receivedHmac || !data) return res.status(400).end();

    if (!PAYMOB_CONFIGURED || !verifyPaymobHmac(data, String(receivedHmac))) {
      console.warn("Paymob webhook: invalid HMAC");
      return res.status(401).end();
    }

    const paymobOrderId = data.order && data.order.id;
    const order = db.orders.find(o => o.paymobOrderId === paymobOrderId);
    if (!order) return res.status(200).end(); // unknown order, nothing to do

    if (order.status === "بانتظار الدفع") {
      if (data.success === true || data.success === "true") {
        order.status = "قيد التجهيز";
      } else {
        order.status = "فشل الدفع";
        restoreStock(order);
      }
      saveDB(db);
    }
    res.status(200).end();
  } catch (err) {
    console.error("Webhook error:", err);
    res.status(200).end(); // acknowledge anyway so Paymob doesn't retry endlessly
  }
});

app.patch("/api/orders/:id", requireAdmin, (req, res) => {
  const order = db.orders.find(o => o.id === Number(req.params.id));
  if (!order) return res.status(404).json({ error: "الطلب غير موجود" });

  const { status } = req.body || {};
  if (!ORDER_STATUSES.includes(status))
    return res.status(400).json({ error: "حالة غير صحيحة" });

  order.status = status;
  saveDB(db);
  res.json(order);
});

// ---------- Public: contact form ----------

app.post("/api/contact", (req, res) => {
  const { name, email, text } = req.body || {};
  if (!name || !email || !EMAIL_RE.test(email) || !text)
    return res.status(400).json({ error: "الرجاء تعبئة جميع الحقول بشكل صحيح" });

  db.messages.push({
    id: db.messages.length ? Math.max(...db.messages.map(m => m.id)) + 1 : 1,
    name: String(name).slice(0, 100),
    email: String(email).slice(0, 100),
    text: String(text).slice(0, 1000),
    createdAt: new Date().toISOString()
  });
  saveDB(db);
  res.status(201).json({ ok: true });
});

// ---------- Public: config ----------

app.get("/api/config", (req, res) => {
  res.json({ paymentsEnabled: PAYMOB_CONFIGURED });
});

// ---------- Admin: dashboard ----------

app.get("/api/admin", requireAdmin, (req, res) => {
  const paidOrders = db.orders.filter(o => PAID_STATUSES.includes(o.status));
  const revenue = paidOrders.reduce((sum, o) => sum + o.total, 0);
  res.json({
    products: db.products.length,
    orders: db.orders.length,
    revenue,
    users: new Set(paidOrders.map(o => o.customer.email)).size,
    recentOrders: db.orders.slice(-15).reverse(),
    allProducts: db.products,
    orderStatuses: ORDER_STATUSES,
    messages: db.messages.slice(-15).reverse(),
    paymentsEnabled: PAYMOB_CONFIGURED
  });
});

// ---------- Admin: products CRUD ----------

app.post("/api/products", requireAdmin, (req, res) => {
  const { name, price, stock, emoji = "🐾" } = req.body || {};
  const trimmedName = String(name || "").trim().slice(0, 60);
  if (!trimmedName || !Number.isFinite(Number(price)) || Number(price) <= 0 || !Number.isFinite(Number(stock)) || Number(stock) < 0)
    return res.status(400).json({ error: "بيانات المنتج غير صحيحة" });

  const product = {
    id: db.products.length ? Math.max(...db.products.map(p => p.id)) + 1 : 1,
    name: trimmedName,
    price: Number(price),
    stock: Math.trunc(Number(stock)),
    emoji: String(emoji || "🐾").slice(0, 8)
  };
  db.products.push(product);
  saveDB(db);
  res.status(201).json(product);
});

app.patch("/api/products/:id", requireAdmin, (req, res) => {
  const product = db.products.find(p => p.id === Number(req.params.id));
  if (!product) return res.status(404).json({ error: "المنتج غير موجود" });

  if (req.body.name !== undefined) {
    const trimmed = String(req.body.name).trim().slice(0, 60);
    if (!trimmed) return res.status(400).json({ error: "اسم المنتج غير صحيح" });
    product.name = trimmed;
  }
  if (req.body.price !== undefined) {
    const price = Number(req.body.price);
    if (!Number.isFinite(price) || price <= 0) return res.status(400).json({ error: "السعر غير صحيح" });
    product.price = price;
  }
  if (req.body.stock !== undefined) {
    const stock = Number(req.body.stock);
    if (!Number.isFinite(stock) || stock < 0) return res.status(400).json({ error: "المخزون غير صحيح" });
    product.stock = Math.trunc(stock);
  }
  if (req.body.emoji !== undefined) {
    product.emoji = String(req.body.emoji).slice(0, 8);
  }

  saveDB(db);
  res.json(product);
});

app.delete("/api/products/:id", requireAdmin, (req, res) => {
  const idx = db.products.findIndex(p => p.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: "المنتج غير موجود" });
  db.products.splice(idx, 1);
  saveDB(db);
  res.json({ ok: true });
});

// ---------- 404 + generic error handler ----------

app.use("/api", (req, res) => res.status(404).json({ error: "المسار غير موجود" }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "خطأ غير متوقع في الخادم" });
});

app.listen(PORT, () => console.log(`PetCare running on http://localhost:${PORT}`));
